$(function()
	{
    $( "input[type=submit], button" )
		.button()
		.click(function( event )
			{
			event.preventDefault();
			});
		  
	$( ".counter" ).button( "option", "icons", { secondary: "ui-icon-triangle-1-e" } );
	$( ".personbtn" ).button( "option", "icons", { primary: "ui-icon-person" } );
	$( ".videobtn" ).button( "option", "icons", { primary: "ui-icon-video" } );
	$( ".infobtn" ).button( "option", "icons", { primary: "ui-icon-info" } );
	$( "#accordion" ).accordion({heightStyle: "content"});
	$( document ).tooltip();
	
	$( "#dialog" ).dialog({
		closeText: "",
		autoOpen: false,
		show: {
			effect: "blind",
			duration: 500
		},
		hide: {
			effect: "blind",
			duration: 500
		}
    });
 
    $( "#opener" ).click(function() {
		$( "#dialog" ).dialog( "open" );
    });
	
	});
  
function btn_onclick(val) 
	{
    window.location.href = val;
	}