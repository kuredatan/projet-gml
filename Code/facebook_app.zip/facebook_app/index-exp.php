<html>
<head>
<style type="text/css">
<!--
@import url("style.css");
-->
</style>
<link href="main.css" rel="stylesheet">
<link href="css/smoothness/jquery-ui-1.10.3.custom.css" rel="stylesheet">
<script src="js/jquery-1.9.1.js"></script>
<script src="js/jquery-ui-1.10.3.custom.js"></script>
</head>
<body>
<div class="ui-widget">
<h1>First Phase Finished!</h1>
<div class="ui-widget">
	<table class="ui-widget">
	<tr>
	<td width=42>
	<img border=0 src="banner.png" height=100>
	</td>
	<td>
	<p>The first phase of the experiment is already finished at 24 March 2014 17:00.<br>We are now in the process of analyzing your data.<br>We will come back to you soon.</p>
	</td>
	</tr>
	</table>
	</div>

<p class="ui-widget"><b>Contact:</b> Behrooz Omidvar-Tehrani (firstname.lastname@imag.fr)</p>
			<p class="ui-widget">Laboratoire d'Informatique de Grenoble, Norwegian University of Science and Technology, INRIA - Nancy Grand Est, University of Washington Tacoma</p>
</body>
</html>