<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Friend Selection</title>
		<link href="css/smoothness/jquery-ui-1.10.3.custom.css" rel="stylesheet">
		<link href="main.css" rel="stylesheet">
		
		<link type="text/css" href="/friendselect/friend-selector/jquery.friend.selector-1.2.1.css" rel="stylesheet" />
		<script type="text/javascript" src="/friendselect/js/libs/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="/friendselect/friend-selector/jquery.friend.selector-1.2.1.js"></script>
		
		<script type="text/javascript">
		jQuery(document).ready(function($) {
		$(".bt-fs-dialog").fSelector({
		onSubmit: function(response){
        document.friendform.elements['friends'].value=response;
		document.getElementById('friendform').submit();
		// alert(document.friendform.elements['friends'].value);
		}
		});
		});
</script>
		
		<style>
		#feedback { font-size: 1.4em; }
		#selectable .ui-selecting { background: #FECA40; }
		#selectable .ui-selected { background: #F39814; color: white; }
		#selectable { list-style-type: none; margin: 0; padding: 0; width: 60%; }
		#selectable li { margin: 3px; padding: 0.4em; font-size: 1.4em; height: 18px; }
		</style>
		<script src="js/jquery-1.9.1.js"></script>
		<script src="js/jquery-ui-1.10.3.custom.js"></script>
		<script>
			$(function() {
			$( "#accordion" ).accordion();
			$( "#buttons1" ).button();
			$( "#buttons2" ).button();
			$( "#buttonr1" ).button();
			$( "#buttonr2" ).button();
			$( "#selectable" ).selectable();
			<?php for($i=0; $i<40; $i++): ?>
			$( "#radioset<?php echo($i); ?>" ).buttonset();
			$( "#tabs<?php echo($i); ?>" ).tabs({ collapsible: true });
			<?php endfor ?>
			// Link to open the dialog
			$( "#dialog-link" ).click(function( event ) { $( "#dialog" ).dialog( "open" ); event.preventDefault(); });
			// Hover states on the static widgets
			$( "#dialog-link, #icons li" ).hover( function() { $( this ).addClass( "ui-state-hover" ); }, function() { $( this ).removeClass( "ui-state-hover" ); });
			});
			
			</script>
	</head>
    <body>
<!-- Facebook Integration  -->
<script src="//connect.facebook.net/en_US/all.js"></script>
<div id="fb-root"></div>
<script type="text/javascript">
  window.fbAsyncInit = function() {
    FB.init({
      appId  			: '373165619491711', // Facebook Application ID
	  secret			: '52398695fc9c166c667fe682b05e3ec8',
      cookie 			: true, // enable cookies to allow the server to access the session
      xfbml  			: true// parse XFBML
     
    });


    FB.getLoginStatus(function(response) {
      if (response.authResponse) {
        $(".connect").attr("class", "logout").text("Logout");
        $(".fs-dialog-container").show();

        $(".logout").click(function(){
          FB.logout(function(response) {
            location.reload();
          });
        });

      } else {

      }
    });

  };
  
  // Load the SDK Asynchronously
  (function(d){
     var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
     js = d.createElement('script'); js.id = id; js.async = true;
     js.src = "//connect.facebook.net/en_US/all.js";
     d.getElementsByTagName('head')[0].appendChild(js);
   }(document));


  jQuery(document).ready(function($){

    $(".connect").click(function(){
      FB.login(function(response) {
        if (response.authResponse) {
          location.reload();
        } else {
          // User cancelled login or did not fully authorize
        }
      }, {scope: 'user_groups'});
    });

  });

</script>




				
<?php
require 'fb/facebook.php';

$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));
$user_id = $facebook->getUser();


        $user_profile = $facebook->api('/me','GET');
        //echo "Name: " . $user_profile['name'];
		$friends = $facebook->api('/me/friends');

	


mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

// record like categories of the user it self
$likes_cat1 = $facebook->api('/me/likes');
foreach($likes_cat1["data"] as $vv)
	{
	// echo("hello");
	// echo($vv["category"]."<br>");
	$q3=mysql_query("INSERT INTO cat (`id`, `uid`, `cat`, `time`) VALUES (NULL, '$user_id', '".$vv["category"]."', 'NOW()')") or die(mysql_error());
	}
// record like categories of the user it self - end

for ($i=0; $i<40; $i++)
	{
	$r=$_POST["radio".$i];
	$m=$_POST["m".$i];
	$uid=$_POST["uid"];
	$hit=$_POST["hit"];
	if ($r!=0)
		$q=mysql_query("INSERT INTO prefs (`id`, `uid`, `exp`, `movie`, `rating`, `timestamp`) VALUES (NULL, '$uid', '$hit', '$m', '$r', NOW())") or die(mysql_error());
	}
	
echo("<center><h2></h2></center>");

?>
		<h1>Done with ratings <?php echo($user_profile['first_name']); ?>!</h1>
		<div class="ui-widget">
			<table class="ui-widget">
			<tr>
			<td width=42>
			<img border=0 src="banner.png" height=100>
			</td>
			<td>
			<p>Now tell us with which friends would you like to see a movie by <a href='javascript:{}' class='bt-fs-dialog'>clicking here</a>.<br>Please select between 10 to 20 friends. <br>Your friends will be invited later to also provide their movie preferences.</p>
			</td>
			</tr>
			</table>
		</div>
<form name="friendform" id="friendform" action="affinity.php" method="post">
<input type="hidden" name="friends" value="" />
</form>
</body>
</html>