<?php
ini_set('display_errors', 'On');
ini_set('max_execution_time', 3600);

mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

$seed_ids=array(1589755539, 1257891665, 1286244355, 704638062, 1538299095, 1005523481, 543512639, 100000111820837, 1091880451, 100001897198678, 100004324450767, 709242198, 1324822416);
$sid=1257891665;
$q=mysql_query("select friend from friends where uid=$sid");
$n=mysql_num_rows($q);
$friend_ids=array_fill(0, $n, "");
for($i=0; $i<$n; $i++)
	{
	$f=mysql_fetch_row($q);
	$friend_ids[$i]=$f[0];
	}
for($h=0; $h<$n; $h++)
	{
	$q1=mysql_query("select mut from mutual where u1=$sid and u2=".$friend_ids[$h]);
	$n1=mysql_num_rows($q1);
	$mut1=array_fill(0, $n1, "");
	for($k=0; $k<$n1; $k++)
	{
		$f1=mysql_fetch_row($q1);
		$mut1[$k]=$f1[0];
	}
	for($j=$h+1; $j<$n; $j++)
	{
		$q2=mysql_query("select mut from mutual where u1=$sid and u2=".$friend_ids[$j]);
		$n2=mysql_num_rows($q2);
		$mut2=array_fill(0, $n2, "");
		for($k=0; $k<$n1; $k++)
		{
			$f2=mysql_fetch_row($q2);
			$mut2[$k]=$f2[0];
		}
		$cnt=0;
		for($k=0; $k<$n1; $k++)
			for($u=0; $u<$n2; $u++)
				if($mut1[$k]==$mut2[$u])
					$cnt++;
		
		echo("$cnt<br>");
	}
	echo("***<br>");
	}
// }
?>