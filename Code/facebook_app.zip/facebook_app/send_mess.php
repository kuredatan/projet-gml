<?php
mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");
$mee=$_GET['m'];
echo("ikhjkhjkhhjkhjkh $mee khjklhkhkljh");
$q=mysql_query("select friend from friends where uid=$mee");
$uids="";
$n=mysql_num_rows($q);
$f=mysql_fetch_row($q);
$uids=$f[0];
for($i=0; $i<$n; $i++)
{
$f=mysql_fetch_row($q);
$uids.=",".$f[0];
}

?>
<div id="fb-root"></div>
<script>
// var sendUIDs="<?php echo($uids); ?>";
  // window.fbAsyncInit = function() {
    // FB.init({
      // appId      : '373165619491711', // App ID
      // status     : true, // check login status
      // cookie     : true, // enable cookies to allow the server to access the session
      // xfbml      : true  // parse XFBML
    // });

       // FB.ui({method: 'apprequests',
     // to: sendUIDs,
     // title: 'GroupRec Movie Recommendation',
     // message: 'Do you want to know with which friend you would like to see which movie? If yes, please participate in our experiment. You will observe a list of 50 movies to rate at least 30 of them!',
   // }, callback);
  // };

  // Load the SDK Asynchronously
  // (function(d){
     // var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
     // if (d.getElementById(id)) {return;}
     // js = d.createElement('script'); js.id = id; js.async = true;
     // js.src = "//connect.facebook.net/en_US/all.js";
     // ref.parentNode.insertBefore(js, ref);
   // }(document));


 

 // function callback(response) {
   // console.log(response);
 // }
</script>
