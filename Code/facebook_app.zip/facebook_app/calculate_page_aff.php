<?php
ini_set('display_errors', 'On');
ini_set('max_execution_time', 3600);
require 'fb/facebook.php';
$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));

mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

function intersect_likes($ar1, $ar2)
{
$cnt=0;
$ar1_data=$ar1["data"];
$ar2_data=$ar2["data"];
foreach($ar1_data as $d1)
	foreach($ar2_data as $d2)
		if($d1["category"]==$d2["category"])
			$cnt++;
return $cnt;
}

$seed_ids=array(1589755539, 1257891665, 1286244355, 704638062, 1538299095, 1005523481, 543512639, 100000111820837, 1091880451, 100001897198678, 100004324450767, 709242198, 1324822416);
foreach($seed_ids as $sid)
{
$s_likes = $facebook->api('/'.$sid.'/likes','GET');
$q=mysql_query("select friend from friends where uid=$sid");
$n=mysql_num_rows($q);
$friend_ids=array_fill(0, $n, "");
for($i=0; $i<$n; $i++)
	{
	$f=mysql_fetch_row($q);
	$friend_ids[$i]=$f[0];
	}
for($h=0; $h<$n; $h++)
	{
	$u1_likes=$facebook->api('/'.$friend_ids[$h].'/likes','GET');
	$common_likes=intersect_likes($s_likes, $u1_likes);
	echo("$sid, ".$friend_ids[$h].", $common_likes<br>");
	}
}
?>