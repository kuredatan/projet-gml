<?php
session_start();

mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");
				
require 'fb/facebook.php';

$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));
$user_id = $facebook->getUser();
	
$c_rnd=rand(0,10);
$hit_type=($c_rnd%2==0)?"cdis":"csim";
$user_in=0;
$seed_name="";

if($user_id)
{
	try
	{
		$user_profile = $facebook->api('/me','GET');
		$q=mysql_query("select uid from friends where friend=$user_id");
		$f=mysql_fetch_row($q);
		$seed_id=$f[0];
		$q1=mysql_query("select exp from prefs where uid=$seed_id");
		$f1=mysql_fetch_row($q1);
		$hit_type=$f1[0];
		$user_in=1;
	}
	catch(FacebookApiException $e)
	{
        $login_url = $facebook->getLoginUrl(); 
        error_log($e->getType());
        error_log($e->getMessage());
    }   
}
else
{
	$login_url = $facebook->getLoginUrl();
}
?>


<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Movie Recommendation Experiment - Second Phase</title>
		<link href="css/excite-bike/jquery-ui-1.10.4.custom.css" rel="stylesheet">
		<link href="main.css" rel="stylesheet">
		<script src="js/jquery-1.9.1.js"></script>
		<script src="js/jquery-ui-1.10.3.custom.js"></script>
		<script>
			$(function() {
			$( "#accordion" ).accordion();
			$( "#buttons1" ).button();
			$( "#buttonr1" ).button();
			$( "#buttons2" ).button();
			$( "#buttonr2" ).button();
			<?php for($i=0; $i<50; $i++): ?>
			$( "#radioset<?php echo($i); ?>" ).buttonset();
			$( "#tabs<?php echo($i); ?>" ).tabs({ collapsible: true });
			<?php endfor ?>
			// Link to open the dialog
			$( "#dialog-link" ).click(function( event ) { $( "#dialog" ).dialog( "open" ); event.preventDefault(); });
			// Hover states on the static widgets
			$( "#dialog-link, #icons li" ).hover( function() { $( this ).addClass( "ui-state-hover" ); }, function() { $( this ).removeClass( "ui-state-hover" ); });
			});
			
			function checkvalue()
			{
				var cnt = 0;
				for (var i=0;i<50;i++)
				{ 
					var tmpid = "rid0-".concat(i);
					// alert(tmpid);
					if (document.getElementById(tmpid).checked) 
					{
						cnt = cnt + 1;
					}
				}
				if (cnt>20)
				{
					var rest=cnt-20;
					var tmptxt = "You need to rate at least ".concat(rest);
					tmptxt = tmptxt.concat(" other movies!");
					alert(tmptxt);
				}
				else
				{
					document.getElementById('mainform').submit();
				}
			}
		</script>
	</head>
    <body>
	<?php if($user_in==1 || $user_id!=''): ?>
		<h1>GroupRec Movie Recommendation</h1>
		<div class="ui-widget">
			<table class="ui-widget">
			<tr>
			<td width=42>
			<img border=1 src="https://graph.facebook.com/<?php echo($user_id) ?>/picture">
			</td>
			<td>
			<p>Do you want to know with which friend you'd like to see which movie? If yes, please participate in our experiment.<br>
			Hello <b><?php echo($user_profile['first_name']); ?></b> (<a href="<?php echo($facebook->getLogoutUrl()); ?>">Logout</a>). Here you observe a list of 50 movies. Please rate at least 30 of them!<br>
			More movie details are available in IMDb website by clicking on the title.</p>
			</td>
			</tr>
			</table>
		</div>
		<form id="mainform" action="done_second_phase.php" method="post">
			<input type="hidden" name="uid" value="<?php echo($user_id); ?>">
			<input type="hidden" name="hit" value="<?php echo($hit_type); ?>">
			<p><button type="button" id="buttons1" onclick="checkvalue();">Submit Ratings</button>
			<button type="reset" id="buttonr1">Reset All Ratings</button></p>
			<table class="ui-widget">
				<?php 
				if ($hit_type=="cdis")
					$q=mysql_query("select id, title, genre, trailer_link, photo, imdb_link, type, rate from movies where type='popular' limit 0,25 union all select id, title, genre, trailer_link, photo, imdb_link, type, rate from movies where type='diversity' order by rand()") or die(mysql_error());
				else
					$q=mysql_query("select id, title, genre, trailer_link, photo, imdb_link, type, rate from movies where type='popular' order by rand()");
				
				$n=mysql_num_rows($q);
				for($i=0; $i<$n; $i+=2):
					$f=mysql_fetch_row($q);
					$f1=mysql_fetch_row($q);
					$movie_title1=$f[1];
					$movie_genre1=$f[2];
					$trailer_link1=$f[3];
					$imdb_link1=$f[5];
					$movie_photo1=$f[4];
					$movie_type1=$f[6];
					$movie_rate1=$f[7];
					$movie_title2=$f1[1];
					$movie_genre2=$f1[2];
					$trailer_link2=$f1[3];
					$imdb_link2=$f1[5];
					$movie_photo2=$f1[4]; 
					$movie_type2=$f1[6];
					$movie_rate2=$f1[7];	
					?>
				<tr>
					<td>
						<div id="tabs<?php echo($i); ?>" width=500>
							<ul>
								<li><a href="#tabs-1"><?php echo("(".($i+1).") ".$movie_title1); ?></a></li>
								<li><a href="#tabs-3">Watch Trailer</a></li>
							</ul>
							<div id="tabs-1">
								<table border=0 class="ui-widget">
									<tr>
										<td width=110 >
											<img border=1 src="<?php echo($movie_photo1); ?>" height="150"  />
										</td>
										<td>
											<input type="hidden" name="m<?php echo($i); ?>" value="<?php echo($f[0]); ?>">
											<b>Title:</b> <a href="<?php echo($imdb_link1); ?>" target="_blank"><?php echo($movie_title1); ?></a><br>
											<b>Genre:</b> <?php echo($movie_genre1); ?></a><br><br>
											<div id="<?php echo("radioset".$i); ?>">
												<b>Your rating:</b>
												<input type="radio" id="<?php echo("rid1-".$i); ?>" name="<?php echo("radio".$i) ?>" value="1"><label for="<?php echo("rid1-".$i); ?>">1</label>
												<input type="radio" id="<?php echo("rid2-".$i); ?>" name="<?php echo("radio".$i) ?>" value="2"><label for="<?php echo("rid2-".$i); ?>">2</label>
												<input type="radio" id="<?php echo("rid3-".$i); ?>" name="<?php echo("radio".$i) ?>" value="3"><label for="<?php echo("rid3-".$i); ?>">3</label>
												<input type="radio" id="<?php echo("rid4-".$i); ?>" name="<?php echo("radio".$i) ?>" value="4"><label for="<?php echo("rid4-".$i); ?>">4</label>
												<input type="radio" id="<?php echo("rid5-".$i); ?>" name="<?php echo("radio".$i) ?>" value="5"><label for="<?php echo("rid5-".$i); ?>">5</label>
												<input type="radio" id="<?php echo("rid0-".$i); ?>" name="<?php echo("radio".$i) ?>" value="0" checked="checked"><label for="<?php echo("rid0-".$i); ?>">No Rating</label>
											</div>
										</td>
									</tr>
								</table>
							</div>
							<div id="tabs-3">
								<iframe width="420" height="150" src="//www.youtube.com/embed/<?php echo($trailer_link1); ?>" frameborder="0" allowfullscreen></iframe>
							</div>
						</div>
					</td>
					<td>
						<div id="tabs<?php echo($i+1); ?>">
							<ul>
								<li><a href="#tabs-1"><?php echo("(".($i+2).") ".$movie_title2); ?></a></li>
								<li><a href="#tabs-3">Watch Trailer</a></li>
								
							</ul>
							<div id="tabs-1">
							<table border=0 class="ui-widget">
								<tr>
									<td width=110 >
										<img border=1 src="<?php echo($movie_photo2); ?>" height="150"  />
									</td>
									<td>
										<input type="hidden" name="m<?php echo($i+1); ?>" value="<?php echo($f1[0]); ?>">
										<b>Title:</b> <a href="<?php echo($imdb_link2); ?>" target="_blank"><?php echo($movie_title2); ?></a><br>
										<b>Genre:</b> <?php echo($movie_genre2); ?></a><br><br>
										<div id="<?php echo("radioset".($i+1)); ?>">
											<b>Your rating:</b>
											<input type="radio" id="<?php echo("rid1-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="1"><label for="<?php echo("rid1-".($i+1)); ?>">1</label>
											<input type="radio" id="<?php echo("rid2-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="2"><label for="<?php echo("rid2-".($i+1)); ?>">2</label>
											<input type="radio" id="<?php echo("rid3-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="3"><label for="<?php echo("rid3-".($i+1)); ?>">3</label>
											<input type="radio" id="<?php echo("rid4-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="4"><label for="<?php echo("rid4-".($i+1)); ?>">4</label>
											<input type="radio" id="<?php echo("rid5-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="5"><label for="<?php echo("rid5-".($i+1)); ?>">5</label>
											<input type="radio" id="<?php echo("rid0-".($i+1)); ?>" name="<?php echo("radio".($i+1)) ?>" value="0" checked="checked"><label for="<?php echo("rid0-".($i+1)); ?>">No Rating</label>
										</div>
									</td>
								</tr>
							</table>
						</div>
	<div id="tabs-3">
	<iframe width="420" height="150" src="//www.youtube.com/embed/<?php echo($trailer_link2); ?>" frameborder="0" allowfullscreen></iframe>
	</div>
		</div>
					</td>
				</tr>
			
				<?php endfor ?>
			</table>
			<br>
			<button type="button" id="buttons2" onclick="checkvalue();">Submit Ratings</button>
			<button type="reset" id="buttonr2">Reset All Ratings</button>
			<p class="ui-widget"><b>Contact:</b> Behrooz Omidvar-Tehrani (firstname.lastname@imag.fr)</p>
			<p class="ui-widget">Laboratoire d'Informatique de Grenoble, Norwegian University of Science and Technology, INRIA - Nancy Grand Est, University of Washington Tacoma</p>
		</form>
		<?php
		else:
		?>
		<center><img src="banner.png" height=200 /></center>
		<center><h2>Do you want to know with which friend you'd like to see which movie? If yes, please participate in our experiment.</h2></center>
		<center><h2>To begin, <a href="<?php echo($login_url); ?>" target="_blank">please login</a>.</h2></center>
		<br><br>
		<center><p>All the data we collect will be anoymized and be destroyed after the experiment. You may contact <b>behrooz [dot] omidvar-tehrani [at] imag [dot] fr</b> for questions regarding the application.</p></center>
		<?php endif ?>
	</body>
</html>