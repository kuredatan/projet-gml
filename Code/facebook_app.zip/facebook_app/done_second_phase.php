<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Experiment Done</title>
		<link href="css/smoothness/jquery-ui-1.10.3.custom.css" rel="stylesheet">
		<link href="main.css" rel="stylesheet">
		<script src="js/jquery-1.9.1.js"></script>
		<script src="js/jquery-ui-1.10.3.custom.js"></script>
	</head>
    <body>
<?php
require 'fb/facebook.php';

$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));
$user_id = $facebook->getUser();
$user_profile = $facebook->api('/me','GET');

mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

for ($i=0; $i<40; $i++)
	{
	$r=$_POST["radio".$i];
	$m=$_POST["m".$i];
	$uid=$_POST["uid"];
	$hit=$_POST["hit"];
	if ($r!=0)
		$q=mysql_query("INSERT INTO prefs (`id`, `uid`, `exp`, `movie`, `rating`, `timestamp`) VALUES (NULL, '$uid', '$hit', '$m', '$r', NOW())") or die(mysql_error());
	}
	
?>
		<h1>Thank you <?php echo($user_profile['first_name']); ?>!</h1>
		<div class="ui-widget">
			<table class="ui-widget">
			<tr>
			<td width=42>
			<img border=0 src="banner.png" height=100>
			</td>
			<td>
			<p>We will come back to you later with some interesting movie suggestions<br>to see with the friends you selected!</p>
			</td>
			</tr>
			</table>
		</div>
</body>
</html>