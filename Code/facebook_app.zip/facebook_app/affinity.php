<html>
<head>
<style type="text/css">
<!--
@import url("style.css");
-->
</style>
<link href="main.css" rel="stylesheet">
<link href="css/smoothness/jquery-ui-1.10.3.custom.css" rel="stylesheet">
<script src="js/jquery-1.9.1.js"></script>
<script src="js/jquery-ui-1.10.3.custom.js"></script>
<script>
	$(function() {
	$( "#tabs" ).tabs({ collapsible: true });
	
	});
</script>
</head>
<body>
<?php
ini_set('display_errors', 'On');
ini_set('max_execution_time', 3600);
function get_desc($value, $max)
{
$interval=$max/5;
$level=round($value/$interval,0);
switch($level)
	{
	case 0:
		return "Very low";
		break;
	case 1:
		return "Low";
		break;
	case 2:
		return "In between";
		break;
	case 3:
		return "High";
		break;
	case 4:
		return "Very high";
		break;
	case 5:
		return "Very high";
	}
}

require 'fb/facebook.php';

$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));
$user_id = $facebook->getUser();

$user_profile = $facebook->api('/me','GET');
$friends = $facebook->api('/me/friends');
				
$user_count=0;
$members=array_fill(0,30,"");
//$members[$user_count++]=$user_id;
$all_friends=$_POST['friends'];
$all_friends=trim($all_friends);
$begin=0;
$end=0;
mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

while($begin<strlen($all_friends))
{
$end=strpos($all_friends,",",$begin);
if($end===FALSE)
	$end=strlen($all_friends);
$uidtemp=substr($all_friends, $begin, $end-$begin);
$q=mysql_query("INSERT INTO friends (`id`, `uid`, `friend`) VALUES (NULL, '$user_id', '$uidtemp');");

// record like categories - start
$likes_cat=$facebook->api('/'.$uidtemp.'/likes');
foreach($likes_cat["data"] as $value)
	{
	$q2=mysql_query("INSERT INTO cat (`id`, `uid`, `cat`, `time`) VALUES (NULL, '$uidtemp', '".$value["category"]."', 'NOW()')");
	}
// record like categories - end

// record mutual friends - start
$mutual_friends = $facebook->api('/me/mutualfriends/'.trim($uidtemp));
foreach($mutual_friends["data"] as $value)
	{
	$q1=mysql_query("INSERT INTO mutual (`id`, `u1`, `u2`, `mut`, `time`) VALUES (NULL, '$user_id', '$uidtemp', '".$value["id"]."', NOW())") or die(mysql_error());
	}
// record mutual friends - end
$begin=$end+1;
}

// print_r($members);




		
// function count_mut($u1, $u2)
// {
// global $facebook;
// $mut1 = $facebook->api('/'.$u2.'/mutualfriends/'.$u1,'GET');
// $mut2 = $facebook->api('/'.$u1.'/mutualfriends/'.$u2,'GET');
// $cnt=0;
// foreach($mut1["data"] as $v1)
	// foreach($mut2["data"] as $v2)
		// if ($v1["id"]==$v2["id"])
			// $cnt++;
// return $cnt;
// }
?>
<div class="ui-widget">
<h1>Thank you <?php echo($user_profile['first_name']); ?>!</h1>
<div class="ui-widget">
	<table class="ui-widget">
	<tr>
	<td width=42>
	<img border=0 src="banner.png" height=100>
	</td>
	<td>
	<p>We will come back to you later with some interesting movie suggestions<br>to see with the friends you selected!</p>
	</td>
	</tr>
	</table>
	</div>

<?php

// $public_affs=array_fill(0,$user_count*($user_count-1)/2,0);
// $spec_affs=array_fill(0,$user_count*($user_count-1)/2,0);
// $public_max=0;
// $spec_max=0;
// $j_public_max=0;
// $j_spec_max=0;
// $mut_max=0;
// $mut_m_max=0;
// $aff_coutner=0;

// $public_likes[0][0]="";
// $spec_likes[0][0]="";
// $nb_likes=array_fill(0, $user_count, 0);
// $p_jaccard=array_fill(0, $user_count, 0);
// $s_jaccard=array_fill(0, $user_count, 0);
// $common_likes=array_fill(0, $user_count, 0);
// $mut_count=array_fill(0, $user_count, 0);
// $mut_movies=array_fill(0, $user_count, 0);

// for($i=0; $i<$user_count; $i++)
	// {
	// $user1_likes = $facebook->api('/'.$members[$i].'/likes','GET');
	// $likes_count=0;
	// foreach($user1_likes["data"] as $v1)
		// {
		// $public_likes[$i][$likes_count]=$v1["category"];
		// $spec_likes[$i][$likes_count++]=$v1["id"];
		// }
	// $nb_likes[$i]=$likes_count;
	// }
	
// $aff_counter=0;
// for($i=0; $i<$user_count; $i++)
	// {
	// $p_count=0;
	// $s_count=0;
	// for($j=$i+1; $j<$user_count; $j++)
		// {
		// $p_union_likes=array_unique(array_merge($public_likes[$i], $public_likes[$j]));
		// $p_mgd_likes[$aff_counter]=count($p_union_likes);
		// $p_intersect_likes=array_unique(array_intersect($public_likes[$i], $public_likes[$j]));
		// $p_common_likes[$aff_counter]=count($p_intersect_likes);
		// $p_jaccard[$aff_counter]=round($p_common_likes[$aff_counter]/$p_mgd_likes[$aff_counter]*100,2);
		
		
		// $s_union_likes=array_unique(array_merge($spec_likes[$i], $spec_likes[$j]));
		// $s_mgd_likes[$aff_counter]=count($s_union_likes);
		// $s_intersect_likes=array_unique(array_intersect($spec_likes[$i], $spec_likes[$j]));
		// $s_common_likes[$aff_counter]=count($s_intersect_likes);
		// $s_jaccard[$aff_counter]=round($s_common_likes[$aff_counter]/$s_mgd_likes[$aff_counter]*100,2);
		
		
		// $mut=count_mut($members[$i], $members[$j]);
		// $mut_count[$aff_counter]=$mut;
		
		// $m1 = $facebook->api('/'.$members[$i].'/movies','GET');
		// $m2 = $facebook->api('/'.$members[$j].'/movies','GET');
		// $mut_mo=0;
		// foreach($m1['data'] as $v1)
			// foreach($m2['data'] as $v2)
				// if ($v1['name']==$v2['name'])
					// $mut_mo++;
					
		// $mut_movies[$aff_counter]=$mut_mo;
		
		// if ($mut_movies[$aff_counter]>$mut_m_max)
			// $mut_m_max=$mut_movies[$aff_counter];
		// if ($p_jaccard[$aff_counter]>$j_public_max)
			// $j_public_max=$p_jaccard[$aff_counter];
		// if ($s_jaccard[$aff_counter]>$j_spec_max)
			// $j_spec_max=$s_jaccard[$aff_counter];
		// if ($p_common_likes[$aff_counter] > $public_max)
			// $public_max = $p_common_likes[$aff_counter];
		// if ($s_common_likes[$aff_counter] > $spec_max)
			// $spec_max = $s_common_likes[$aff_counter];
		// if ($mut > $mut_max)
			// $mut_max = $mut;
		// $aff_counter++;
		// }
	
	// }
	
	
	
	

	// $aff_coutner=0;
	?>
<!-- <div id="tabs" width=500>
<ul>
<li><a href="#tabs-1">Quantitative</a></li>
<li><a href="#tabs-3">Qualitative</a></li>
</ul>
<div id="tabs-1">
	<table id="box-table-b" summary="Affinity Results">
	<thead>
    	<tr>
        	<th scope="col">Pair</th>
			<th scope="col">#Page</th>
			<th scope="col">#Cat</th>
			<th scope="col">#Mutual</th>
			<th scope="col">#MutMovies</th>
            <th scope="col">nSpec %</th>
            <th scope="col">nPub %</th>
            <th scope="col">jSpec %</th>
			<th scope="col">jPub %</th>
			<th scope="col">Avg %</th>
			<th scope="col">jAvg %</th>
			<th scope="col">wAvg %</th>
			<th scope="col">wjAvg %</th>
			<th scope="col">nSocial %</th>
			<th scope="col">nMovies %</th>
        </tr>
    </thead>
	<tbody> -->
	<?php
// $aff_count=0;
// for($i=0; $i<$user_count; $i++)
	// {
	// $user1_profile = $facebook->api('/'.$members[$i],'GET');
	// echo("User ".$user1_profile["name"]." has ".count($public_likes[$i])." available likes!<br>");
	//echo("$public_max--$spec_max<br>");
	// for($j=$i+1; $j<$user_count; $j++)
		// {
		//echo("$public_max--$spec_max<br>");
		// $nPub=round($p_common_likes[$aff_count]/$public_max*100,2);
		// $nSpec=round($s_common_likes[$aff_count]/$spec_max*100,2);
		// $social=round($mut_count[$aff_count]/$mut_max*100,2);
		// $mut_m=round($mut_movies[$aff_count]/$mut_m_max*100,2);
		// $user2_profile = $facebook->api('/'.$members[$j],'GET');
		// $pub_desc=get_desc($p_common_likes[$aff_count], $public_max);
		// $spec_desc=get_desc($s_common_likes[$aff_count], $spec_max);
		// $j_pub_desc=get_desc($p_jaccard[$aff_count], $j_public_max);
		// $j_spec_desc=get_desc($s_jaccard[$aff_count], $j_spec_max);
		// if ($s_common_likes[$aff_count]==$spec_max)
			// $common_pg="<b>".$s_common_likes[$aff_count]."</b>";
		// else
			// $common_pg=$s_common_likes[$aff_count];
		// if ($p_common_likes[$aff_count]==$public_max)
			// $common_cat="<b>".$p_common_likes[$aff_count]."</b>";
		// else
			// $common_cat=$p_common_likes[$aff_count];
		// $avg=round(($nSpec+$nPub)/2,2);
		// $javg=round(($s_jaccard[$aff_count]+$p_jaccard[$aff_count])/2,2);
		// $wavg=round(($s_common_likes[$aff_count]/$spec_max)*$nSpec+(($spec_max-$s_common_likes[$aff_count])/$spec_max)*$nPub,2);
		// $wjavg=round(($s_common_likes[$aff_count]/$spec_max)*$s_jaccard[$aff_count]+(($spec_max-$s_common_likes[$aff_count])/$spec_max)*$p_jaccard[$aff_count],2);
		// $d_avg=get_desc($avg,max($public_max, $spec_max));
		// $d_javg=get_desc($javg,100);
		// $d_wavg=get_desc($wavg,100);
		// $d_wjavg=get_desc($wjavg,100);
		
		// echo("<tr><td>".$user1_profile["first_name"]." with ".$user2_profile["first_name"]."</td><td>$common_pg</td><td>$common_cat</td><td>$mut_count[$aff_count]</td><td>$mut_movies[$aff_count]</td><td>$nSpec</td><td>$nPub</td><td>".$s_jaccard[$aff_count]."</td><td>".$p_jaccard[$aff_count]."</td><td>$avg</td><td>$javg</td><td>$wavg</td><td>$wjavg</td><td>$social</td><td>$mut_m</td></tr>");
		// $aff_count++;
		// }
	// }
// echo("</tbody></table>");

?>
<!-- </div>
<div id="tabs-3">
	<table id="box-table-b" summary="Affinity Results">
	<thead>
    	<tr>
        	<th scope="col">Pair</th>
			<th scope="col">#Page</th>
			<th scope="col">#Cat</th>
			<th scope="col">#Mutual</th>
			<th scope="col">#MutMovies</th>
            <th scope="col">nSpec %</th>
            <th scope="col">nPub %</th>
            <th scope="col">jSpec %</th>
			<th scope="col">jPub %</th>
			<th scope="col">Avg %</th>
			<th scope="col">jAvg %</th>
			<th scope="col">wAvg %</th>
			<th scope="col">wjAvg %</th>
			<th scope="col">nSocial %</th>
			<th scope="col">nMovies %</th>
        </tr>
    </thead>
	<tbody> -->
	<?php
// $aff_count=0;
// for($i=0; $i<$user_count; $i++)
	// {
	// $user1_profile = $facebook->api('/'.$members[$i],'GET');
	// echo("User ".$user1_profile["name"]." has ".count($public_likes[$i])." available likes!<br>");
	//echo("$public_max--$spec_max<br>");
	// for($j=$i+1; $j<$user_count; $j++)
		// {
		//echo("$public_max--$spec_max<br>");
		// $nPub=round($p_common_likes[$aff_count]/$public_max*100,2);
		// $nSpec=round($s_common_likes[$aff_count]/$spec_max*100,2);
		// $user2_profile = $facebook->api('/'.$members[$j],'GET');
		// $pub_desc=get_desc($p_common_likes[$aff_count], $public_max);
		// $spec_desc=get_desc($s_common_likes[$aff_count], $spec_max);
		// $j_pub_desc=get_desc($p_jaccard[$aff_count], $j_public_max);
		// $j_spec_desc=get_desc($s_jaccard[$aff_count], $j_spec_max);
		// if ($s_common_likes[$aff_count]==$spec_max)
			// $common_pg="<b>".$s_common_likes[$aff_count]."</b>";
		// else
			// $common_pg=$s_common_likes[$aff_count];
		// if ($p_common_likes[$aff_count]==$public_max)
			// $common_cat="<b>".$p_common_likes[$aff_count]."</b>";
		// else
			// $common_cat=$p_common_likes[$aff_count];
		// $avg=round(($nSpec+$nPub)/2,2);
		// $javg=round($s_jaccard[$aff_count]+$p_jaccard[$aff_count]/2,2);
		// $wavg=round(($s_common_likes[$aff_count]/$spec_max)*$nSpec+(($spec_max-$s_common_likes[$aff_count])/$spec_max)*$nPub,2);
		// $wjavg=round(($s_common_likes[$aff_count]/$spec_max)*$s_jaccard[$aff_count]+(($spec_max-$s_common_likes[$aff_count])/$spec_max)*$p_jaccard[$aff_count],2);
		// $d_avg=get_desc($avg,100);
		// $d_javg=get_desc($javg,100);
		// $d_wavg=get_desc($wavg,100);
		// $d_wjavg=get_desc($wjavg,100);
		// $s_desc=get_desc($mut_count[$aff_count], $mut_max);
		// $mov_desc=get_desc($mut_movies[$aff_count], $mut_m_max);
		// echo("<tr><td>".$user1_profile["first_name"]." with ".$user2_profile["first_name"]."</td><td>$common_pg</td><td>$common_cat</td><td>$mut_count[$aff_count]</td><td>$mut_movies[$aff_count]</td><td>$spec_desc</td><td>$pub_desc</td><td>$j_spec_desc</td><td>$j_pub_desc</td><td>$d_avg</td><td>$d_javg</td><td>$d_wavg</td><td>$d_wjavg</td><td>$s_desc</td><td>$mov_desc</td></tr>");
		// $aff_count++;
		// }
	// }
// echo("</tbody></table>"); ?>
<!-- </div>
</div>
<h1>Attributes</h1>
<ul class="ui-widget">
<li><b>#Page</b>: The number of common liked Facebook pages between pair of users. The maximum is marked as bold.</li>
<li><b>#Cat</b>: Each Facebook page has a category. For instance the page for "Baaziz" (an Algerian singer) and "Rita Abatzi" (a Greek singer) both hold a same category i.e. "Singer". This attribute is the number common Facebook page categories between pair of users.  The maximum is marked as bold.</li>
<li><b>#Mutual</b>: The number of mutual friends between pair of users</li>
<li><b>#MutMovies</b>: The number of common liked movies between pair of users</li>
</ul>

<h1>Affinity Scores</h1>
<ul class="ui-widget">
<li><b>nSpec</b>: Normalized amount of common liked pages between pair of users. The normalization is done locally.</li>
<li><b>nPub</b>: Normalized amount of common liked page categories between pair of users</li>
<li><b>jSpec</b>: Jaccard similarity between set of liked pages of pair of users i.e. jSpec(u1, u2)=(size(intersect(page_like(u1), page_like(u2))))/(size(union(page_like(u1), page_like(u2))))*100</li>
<li><b>jPub</b>: Jaccard similarity between set of liked page categories of pair of users i.e. jPub(u1, u2)=(size(intersect(cat_page_like(u1), cat_page_like(u2))))/(size(union(cat_page_like(u1), cat_page_like(u2))))*100</li>
<li><b>Avg</b>: Average of nSpec and nPub i.e. simply "(nSpec+nPub)/2"</li>
<li><b>jAvg</b>: Average of jSpec and jPub i.e. simple "(jSpec+jPub)/2"</li>
<li><b>wAvg</b>: Weighted average of nSpec and nPub. The weight is based on number of common pages. If there exist lots of common pages between the pair of user, the nSpec gets more weight than nPub, and the way around i.e. wAvg(u1, u2)=(#Page/max_common_page)*(nSpec)+((max_common_page - #Page)/max_common_page)*(nPub)</li>
<li><b>jwAvg</b>: Weighted average of jSpec% and jPub% with the same intuition as wAvg.</li>
<li><b>nSocial</b>: Normalized amount of mutual friends</li>
<li><b>nMovies</b>: Normalized amount of mutual liked movies</li>
<li>Affinity scores are shown in two different formats: quantitative and qualitative. All scores are locally descritized with equal width strategy to five categories: "very low", "low", "in between", "high" and "very high".</hi>
</ul> -->
</body>
</html>