<?php
//require 'fb/facebook.php';
ini_set('display_errors', 'On');

//$facebook = new Facebook(array('appId'  => '373165619491711', 'secret' => '52398695fc9c166c667fe682b05e3ec8', ));

mysql_pconnect("localhost","root","zEx1b%61");
mysql_select_db("movies");

$rr=array(1286244355, 704638062, 1538299095, 1005523481, 543512639, 100000111820837, 1091880451, 100001897198678, 100004324450767, 709242198, 1324822416);

foreach($rr as $v)
{
$q=mysql_query("select friend from friends where uid=$v") or die(mysql_error());
$n=mysql_num_rows($q);

for($i=0; $i<$n; $i++)
{
$f=mysql_fetch_row($q);
// $user_profile = $facebook->api('/'.$f[0],'GET');
// echo($user_profile["name"]."<br>");
echo($f[0]."<br>");
}
echo("***<br>");
}
?>